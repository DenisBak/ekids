import pygame
window = pygame.display.set_mode((512, 448))
pygame.display.set_caption('Mario')
screen = pygame.Surface((512, 448))
inGame = True
clock = pygame.time.Clock()
imgl = pygame.image.load('images\\marioAL.png')
imgr = pygame.image.load('images\\marioAR.png')
imgcl = pygame.image.load('images\\marioCL.png')
imgcr = pygame.image.load('images\\marioCR.png')
img = imgl
x = 250
y = 200
v = 0
jump = False
while inGame:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            inGame = False
            pygame.quit()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RIGHT]:
        x += 3
        img = imgr
    if keys[pygame.K_LEFT]:
        x -= 3
        img = imgl
    if keys[pygame.K_SPACE]:
        if not jump:
            v = -10
            img = imgcr
        jump = True
    if jump:
        y += v
        v += 1
        if v == 11:
            jump = False
            img = imgr
    screen.fill((0,0,255))
    screen.blit(img, (x, y))
    window.blit(screen, (0, 0))
    pygame.display.flip()
    clock.tick(50)