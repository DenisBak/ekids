import pygame
from pygame.sprite import Sprite, Group

WORLD_HEIGHT = 14*16*2
WORLD_WIDTH = 16*16*2
SCENE_WIDTH = WORLD_WIDTH # Временно

# Скорость анимации объектов
OBJ_ANIM_SPEED = 10

window = pygame.display.set_mode((WORLD_WIDTH, WORLD_HEIGHT))
pygame.display.set_caption("Mario")

# Создаем экран
screen = pygame.Surface((SCENE_WIDTH, WORLD_HEIGHT))
# Создаем фон
screenbg = pygame.Surface((SCENE_WIDTH, WORLD_HEIGHT))

animGroup = Group()  # Группа для анимированных объектов
objGroup = Group()  # Группа для всех объектов (анимированных и нет)

# Массив с инфомацией обо всех объектах в игре:
T_QUESTION = 'question'
world_data = {
    'obj': {
        T_QUESTION: [
            (3, 3),
            (4, 3),
        ]
        }
    }


''' Класс который загрузит все картинки '''
class Imgs:
    def __init__(self):
        Imgs.question_imgs = [pygame.image.load('images\\obj\\q' + str(i+1) + '.png').convert_alpha() for i in range(3)]

''' Класс загружает все объекты'''
class World:
    def __init__(self):
        screenbg.fill((107, 140, 255)) # заливаем фон голубым
        # бежим по массиву с информацией обо всех объектах в игре
        for wdt in world_data:
            if wdt == 'obj':
                for objt in world_data[wdt]:
                    for coord in world_data[wdt][objt]:
                        if objt == T_QUESTION:
                            x, y = coord
                            Question(x * 16 * 2, 400 - y * 16 * 2)


''' Класс для всех объектов игры '''
class Obj(Sprite):
    def __init__(self, imgs, x, y):
        Sprite.__init__(self)
        self.images = []  # массив для всех кадров спрайта, будут меняться один за другим
        self.f = 0  # номер текущей картинки из массива
        # заполняем массив:
        for im in imgs:
            self.images.append(im)
        # обязательные два параметра должны называться именно image и rect.
        # image будет браться при вызове метода группы .draw, а rect будет браться при вызове методов сравнения пересечения
        self.image = self.images[0]
        self.rect = self.image.get_rect()
        # если картинка одна, то анимация не нужна, иначе добавим объект в группу анимации
        if len(self.images) > 1:
            self.add(animGroup)
        # все объекты поместим во вторую группу, чтобы можно было их отрисовать
        self.add(objGroup)
        # с помощью присваивания поместим левый нижний угол в координаты (x,y)
        self.rect.bottomleft = x, y

    ''' Эта процедура будет вызываться каждый кадр, чтобы анимация объекта была не быстрой, добавим деление '''
    def anim(self):
        # меняем картинку на соответствующую текущей:
        self.image = self.images[self.f // OBJ_ANIM_SPEED]
        # берем следующую картинку:
        self.f += 1
        if self.f // OBJ_ANIM_SPEED >= len(self.images):
            self.f = 0

''' Объект "Блок с вопросиком" '''
class Question(Obj):
    def __init__(self, x, y):
        Obj.__init__(self, Imgs.question_imgs, x, y)


# Загружаем все картинки
Imgs()
# Загружаем мир:
World()

clock = pygame.time.Clock()
inGame = True
while inGame:

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            inGame = False
            pygame.quit()
            exit()
    
    # Рисуем фон
    screen.blit(screenbg, (0, 0))
    ''' Вызываем анимацию анимированных объектов '''
    for a in animGroup:
        a.anim()
    ''' Рисуем все остальные объекты '''
    objGroup.draw(screen)

    # Рисуем наш экран
    window.blit(screen, (0, 0))

    pygame.display.flip()

    clock.tick(50)
